import './App.css';
import React from 'react';
import { Map, GoogleApiWrapper, Marker } from 'google-maps-react';
import SelectSearch, { useSelect } from 'react-select-search';




const API_KEY = "AIzaSyDHHQGZhxk4i83ghz2rs59gZfYxJ3FUzFo";






const CustomSelect = ({ options, value, multiple, disabled }) => {
  const [snapshot, valueProps, optionProps] = useSelect({
      options,
      value,
      multiple,
      disabled,
  });

  return (
      <div>
          <button {...valueProps}>{snapshot.displayValue}</button>
          {snapshot.focus && (
              <ul>
                  {snapshot.options.map((option) => (
                      <li key={option.value}>
                          <button {...optionProps} value={option.value}>{option.name}</button>
                      </li>
                  ))}
              </ul>
          )}
      </div>
  );
};

function App(props) {

  const [currentLocation, setCurentLocation] = React.useState(null);
  const [pickupLocation, setPickupLocation] = React.useState(null);
  const [deliveryLocation, setDeliveryLocation] = React.useState(null);
  const [pickup_search, setPickupSearch] = React.useState("");
  const [delivery_search, setDeliverySearch] = React.useState("");
  const [address_list, setAddressList] = React.useState([{
    name: "test-1",
    value: 1
  },
  {
    name: "test-2",
    value: 2
  },
  {
    name: "test-3",
    value: 3
  }
]);
  const [pins, setPins] = React.useState([]);

  React.useEffect(() => {
    navigator.geolocation.getCurrentPosition(function (position) {
      const location = {
        name: "current Location",
        value: "currentLocation",
        lat: position.coords.latitude, 
        lng: position.coords.longitude
      };
      setCurentLocation(location);
      setPins([ location ]);
    });
	}, []);
  
  const filterPickupAddress = (value) => {
    return (value) => {
      const result = address_list.filter(option => Object.values(option).some(val => (val).toString().includes(value)));
      console.log([ currentLocation, ...result ])
      return currentLocation ? [ currentLocation, ...result ] : result;
    };
  }

  const getOptions = (query) => {
    console.log(query) 
    if (!query) return [];
      return new Promise(async (resolve, reject) => {
        try {
          const db_locations = await fetch(`http://192.168.1.116:8000/api/locations/search/${query}`)
          console.log("db_locations ", db_locations)
          const google_locations = await fetch(`https://maps.googleapis.com/maps/api/place/textsearch/json?query=${query}&radius=50&key=${API_KEY}`)
          console.log("google_locations => ", google_locations)
  
          resolve([])
        } catch (error) {
          reject(error)
        }
      });
}

  return (
    <div className="App">
      <SelectSearch 
        // options={address_list} 
        search
        getOptions={(query) => {
          return new Promise((resolve, reject) => {
              fetch(`http://192.168.1.116:8000/api/locations/search/${query}`)
                  .then(response => response.json())
                  .then(({ locations }) => {
                      resolve(locations);
                  })
                  .catch(reject);
          });
      }}
        // filterOptions={filterPickupAddress}
        // value={pickup_search} 
        name="pickup_address" 
        onChange={(value, selected_option) => {
          console.log(value, selected_option)
        }}
        placeholder="Choose your pickup address"
      />
      <SelectSearch 
        options={address_list}
        search 
        // value={delivery_search} 
        name="delivery_address" 
        onChange={(e) => {
          // setPickupSearch(e.target.value)
        }}
        placeholder="Choose your delivery address"
      />
      <Map
        google={props.google}
        zoom={18}
        center={currentLocation}
        // bounds={pins}
        options={{streetViewControl: false}}
      >
        {currentLocation ?
          <Marker key="currentLocation"
            position={currentLocation}
          />
          : null
        }
        {pickupLocation ?
          <Marker key="pickupLocation"
            position={pickupLocation}
          />
          : null
        }
        {deliveryLocation ?
          <Marker key="deliveryLocation"
            position={deliveryLocation}
          />
          : null
        }
      </Map>
    </div>
  );
}

export default GoogleApiWrapper({
  apiKey: API_KEY
})(App);
